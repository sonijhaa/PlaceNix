const chatDiv = document.getElementById('chat');
const input = document.getElementById('msg');
const btn = document.getElementById('send');
const API_BASE = 'http://127.0.0.1:8000';

function appendMessage(role, text) {
  const el = document.createElement('div');
  el.className = role === 'user' ? 'text-right my-2' : 'text-left my-2';
  el.innerHTML = `<div class='inline-block p-2 rounded ${role==='user'?'bg-indigo-100':'bg-gray-100'}'>${text}</div>`;
  chatDiv.appendChild(el);
  chatDiv.scrollTop = chatDiv.scrollHeight;
}

btn.addEventListener('click', () => {
  const message = input.value.trim();
  if(!message) return;
  appendMessage('user', message);
  input.value = '';
  // Use SSE streaming
  const url = API_BASE + '/stream-chat?q=' + encodeURIComponent(message);
  const es = new EventSource(url);
  let acc = '';
  appendMessage('assistant', ''); // placeholder last message
  const lastChildIndex = chatDiv.children.length - 1;
  es.onmessage = e => {
    acc += e.data;
    chatDiv.children[lastChildIndex].innerHTML = `<div class='inline-block p-2 rounded bg-gray-100'>${acc}</div>`;
  };
  es.onerror = () => es.close();
});
