    # Placenix Backend

    ## Setup

    1. Create a .env file with:

OPENAI_API_KEY=your_key_here
CHROMA_DIR=./chroma_db

    2. Install requirements:

pip install -r requirements.txt

    3. Run server:

uvicorn app.main:app --reload --port 8000

    Endpoints:
    - POST /api/chat -> {message}
    - GET /stream-chat?q=... -> SSE streaming
    - POST /api/ingest -> {docs, metadatas, ids}
    - POST /api/rag-chat -> {message}
    - POST /api/resume/analyze -> multipart file upload
    - POST /api/predict -> {cgpa, backlogs, internships, projects}
