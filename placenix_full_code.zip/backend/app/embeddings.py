# embeddings.py - wrapper for OpenAI embeddings
import openai
from .config import OPENAI_API_KEY
openai.api_key = OPENAI_API_KEY

def embed_text(texts: list):
    resp = openai.Embedding.create(model="text-embedding-3-small", input=texts)
    return [r['embedding'] for r in resp.data]
