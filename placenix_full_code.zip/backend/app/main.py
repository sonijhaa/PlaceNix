# main.py - FastAPI app with SSE streaming endpoint
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
import openai
from .config import OPENAI_API_KEY
from .api_chat import router as chat_router
openai.api_key = OPENAI_API_KEY

app = FastAPI(title='Placenix Backend')
app.include_router(chat_router, prefix='/api')

@app.get('/')
async def root():
    return {'status': 'Placenix backend running'}

@app.get('/stream-chat')
async def stream_chat(q: str):
    def event_stream():
        for chunk in openai.ChatCompletion.create(model='gpt-4o-mini', messages=[{'role':'user','content':q}], stream=True):
            if 'choices' in chunk:
                delta = chunk['choices'][0].get('delta', {})
                if 'content' in delta:
                    yield f"data: {delta['content']}\n\n"
    return StreamingResponse(event_stream(), media_type='text/event-stream')
