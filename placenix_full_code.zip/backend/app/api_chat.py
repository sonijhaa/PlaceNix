# api_chat.py - chat, rag, ingest, resume analyze, predict endpoints
from fastapi import APIRouter, File, UploadFile, HTTPException
from pydantic import BaseModel
import openai, json, tempfile
from .config import OPENAI_API_KEY
from .vector_store import add_documents, query_similar
import pdfplumber

openai.api_key = OPENAI_API_KEY
router = APIRouter()

class Query(BaseModel):
    message: str
    conversation_id: str | None = None

@router.post('/chat')
async def chat(query: Query):
    messages = [
        {'role': 'system', 'content': 'You are Placenix — an expert placement assistant.'},
        {'role': 'user', 'content': query.message}
    ]
    resp = openai.ChatCompletion.create(model='gpt-4o-mini', messages=messages, max_tokens=512)
    return {'reply': resp.choices[0].message.content}

@router.post('/rag-chat')
async def rag_chat(query: Query):
    # retrieve top docs
    res = query_similar(query.message, n=4)
    contexts = []
    try:
        docs = res.get('documents', [])[0]
        metadatas = res.get('metadatas', [])[0]
        for d, m in zip(docs, metadatas):
            contexts.append(f"Source metadata: {m}\n{d}")
    except Exception:
        pass
    prompt = "You are Placenix. Use the following context to answer the user's question.\n\n" + "\n---\n".join(contexts) + "\nUser: " + query.message
    resp = openai.ChatCompletion.create(model='gpt-4o-mini', messages=[{'role':'user','content':prompt}], max_tokens=512)
    return {'reply': resp.choices[0].message.content, 'sources': contexts}

@router.post('/ingest')
async def ingest(payload: dict):
    # payload: {docs: [...], metadatas: [...], ids: [...]}
    try:
        docs = payload.get('docs', [])
        metas = payload.get('metadatas', [])
        ids = payload.get('ids', [])
        if not docs:
            raise HTTPException(status_code=400, detail='No docs provided')
        add_documents(docs, metas, ids)
        return {'status':'ok', 'ingested': len(docs)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post('/resume/analyze')
async def analyze_resume(file: UploadFile = File(...)):
    contents = await file.read()
    text = ''
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
            tmp.write(contents)
            tmp_path = tmp.name
        with pdfplumber.open(tmp_path) as pdf:
            pages = [p.extract_text() or '' for p in pdf.pages]
            text = '\n'.join(pages)
    except Exception:
        try:
            text = contents.decode('utf-8', errors='ignore')
        except Exception:
            text = ''
    prompt = f"You are Placenix. Score this resume out of 100 and provide 5 short actionable improvements. Resume:\n{text[:6000]}"
    resp = openai.ChatCompletion.create(model='gpt-4o-mini', messages=[{'role':'user','content':prompt}], max_tokens=500)
    return {'analysis': resp.choices[0].message.content}

@router.post('/predict')
async def predict(payload: dict):
    # simple heuristic probability
    try:
        cgpa = float(payload.get('cgpa', 0))
        backlogs = int(payload.get('backlogs', 0))
        internships = int(payload.get('internships', 0))
        projects = int(payload.get('projects', 0))
        cgpa_term = min(max(cgpa / 10.0, 0), 1.0)
        backlogs_term = max(0.0, 1.0 - 0.1 * backlogs)
        internships_term = min(internships / 3.0, 1.0)
        projects_term = min(projects / 3.0, 1.0)
        score = 0.6 * cgpa_term + 0.15 * backlogs_term + 0.15 * internships_term + 0.1 * projects_term
        return {'probability_percent': round(score * 100, 2)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
