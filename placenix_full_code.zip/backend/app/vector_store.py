# vector_store.py - Chroma vector helper (local duckdb+parquet)
from chromadb import Client
from chromadb.config import Settings
from chromadb.utils import embedding_functions
from .config import OPENAI_API_KEY, CHROMA_DIR

client = Client(Settings(chroma_db_impl="duckdb+parquet", persist_directory=CHROMA_DIR))
embed_fn = embedding_functions.OpenAIEmbeddingFunction(api_key=OPENAI_API_KEY, model_name="text-embedding-3-small")

def get_collection(name="placement_data"):
    try:
        return client.get_collection(name)
    except Exception:
        return client.create_collection(name=name, embedding_function=embed_fn)

def add_documents(docs: list, metadatas: list, ids: list):
    coll = get_collection()
    coll.add(documents=docs, metadatas=metadatas, ids=ids)

def query_similar(query_text, n=4, where=None):
    coll = get_collection()
    if where:
        res = coll.query(query_texts=[query_text], n_results=n, where=where)
    else:
        res = coll.query(query_texts=[query_text], n_results=n)
    return res
